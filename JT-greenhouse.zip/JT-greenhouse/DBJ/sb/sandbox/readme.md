# Greenhouse Control System

----
## Hardware

Greenboard: Control board for small-scale greenhouse control. 
ATMEL328P

----
## Software
Production: FreeRTOS + AVR-C
Proto: Arduino 

----
## thanks
* David Austin
* Jarred Trottier
* Brent Rubell