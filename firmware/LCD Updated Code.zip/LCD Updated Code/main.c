
#ifndef F_CPU
#define F_CPU 16000000UL // 16 MHz clock speed
#endif


#define D4 eS_PORTB2
#define D5 eS_PORTB3
#define D6 eS_PORTB4
#define D7 eS_PORTB5
#define RS eS_PORTC4
#define En eS_PORTC5

#include <avr/io.h>
#include <util/delay.h>
#include "lcd.h"
#include <avr/io.h>

int main(void)
{
	
	DDRB |= (1<<DDB2)|(1<<DDB3)|(1<<DDB4)|(1<<DDB5);
	DDRC |= (1<<DDC4)|(1<<DDC5);
	Lcd4_Clear();
	//int i;
	char buffer[30];
	uint8_t sTemp = 35;
	uint8_t pval = 100;
	uint8_t temp = 40;
	uint8_t humid =40;
	uint8_t servo = 200;
	uint8_t lval = 100;
	itoa(sTemp,buffer,10);
	Lcd4_Init();
	Lcd4_Set_Cursor(0,0);
	Lcd4_Write_String("Set:");
	Lcd4_Set_Cursor(0,4);
	Lcd4_Write_String(buffer);
	Lcd4_Set_Cursor(0,8);
	Lcd4_Write_String("C;T:");
	itoa(temp,buffer,10);
	Lcd4_Write_String(buffer);
	Lcd4_Set_Cursor(0,13);
	Lcd4_Write_String("C;H:");
	itoa(humid,buffer,10);
	Lcd4_Write_String(buffer);
	Lcd4_Write_String("%");
	Lcd4_Set_Cursor(2,0);
	Lcd4_Write_String("LVal:");
	itoa(lval,buffer,10);
	Lcd4_Write_String(buffer);
	Lcd4_Set_Cursor(2,9);
	Lcd4_Write_String(" SVal:");
	itoa(servo,buffer,10);
	Lcd4_Write_String(buffer);
	Lcd4_Set_Cursor(3,0);
	Lcd4_Write_String("Action:");
	Lcd4_Set_Cursor(4,0);
	Lcd4_Write_String("No errors");
	while(1)
	{
		
		//Lcd4_Set_Cursor(1,1);
		//Lcd4_Write_String("string2");
		//_delay_ms(2000);
		//Lcd4_Set_Cursor(4,2);
		//Lcd4_Write_String("string3");
		//_delay_ms(2000);
	}
}