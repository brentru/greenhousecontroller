/*
 * main.c
 * ece388/team1/greenhouseproject
 * david austin, brent rubell, jarred trottier
 */ 

#include "alldecs.h"
#define _BV(bit) (1 << (bit))


//	adc vector 
ISR(ADC_vect)
{
	PORTD = ADCL;
	PORTB = ADCH;
}

//	main loop
main()
{
	// local vars
	float temp_low=0;
	float temp_high=0;
	float temp;
	float humidity;
	
	//	reset servo position
	turn_middle()
	//	interrupts
	sei();
	// init serial comms
	USARTINIT();
	//	transmit a welcome message to terminal
	USART_TRANSMIT('b');  
	USART_TRANSMIT('o');  
	USART_TRANSMIT('o');  
	USART_TRANSMIT('t');  
	
	//	RELAY
	//	set as output
	relay_DDR |= (1<<relay_OUTPUTPIN); 
	//	initialize as low
	relay_PORT|= (0<<relay_OUTPUTPIN); 
	lightOn();

	//	LCD 
	DDRB = 0xFF;
	DDRC = 0xFF;
	Lcd4_Clear();
	Lcd4_Init();
	
	//	hbridge
	//	enable DDRD of pins 3,5,6,7 as outputs
	DDRD |= (11101000);
	PORTD |= (LOW<<hbridge_ENA);
	PORTD |= (LOW<<hbridge_ENB);
	PORTD |= (HIGH<<hbridge_IN1);
	PORTD |= (HIGH<<hbridge_IN3);
	
	//	Servo Timer (ISR)
	TCCR1A|=(1<<COM1A1)|(1<<COM1B1)|(1<<WGM11);        //NON Inverted PWM
	TCCR1B|=(1<<WGM13)|(1<<WGM12)|(1<<CS11)|(1<<CS10); //PRESCALER=64 MODE 14(FAST PWM)
	//	fPWM=50Hz
	ICR1=4999;  
	DDRD|=(1<<PORTD4)|(1<<PORTD5);
	
	/* CUSTOMER PROFILE SETUP */
	#ifdef LETTUCE
		//	Plant: Lettuce 
		temp_low = 15;
		temp_high = 50;
	#ifdef TOMATO
		//	PLANT: Tomato 
		temp_low = 10;
		temp_high = 55;
	#else
		//	CUSTOM PLANT
		temp_high = 10;
		temp_low = 35;
	#endif 
	
	//	rt control loop
	while(1)
	{
		//	get photoresistor value
		ADCSRA|= (1<<ADSC);
		if(ADCSRA <=350)
		{
			turn_right();
			//	turn relay off
			lightOff();
		}
		else
		{
			turn_left();
			lightOn();
		}
		//	get DHT data
		dht_getdata(temp,humidity);
		//	DHT control loop
		if((temp>=temp_high))
		{
			turnOnFan();
		}
		else
		{
			//	do nothing
		}
		//	water level loop
		int soillvl = analogSoilRead();
		int waterlvl = analogWaterRead();
		if(soillvl==SOIL_LOW)
		{
			while(soillvl < SOIL_LOW)
			{
			Lcd4_Clear();
			Lcd4_Set_Cursor(0,0);
			Lcd4_Write_String("Filling Soil");
			_delay_ms(2000);
			turnOnPump();
			}
			turnOffPump();
			Lcd4_Clear();
		}
		else if(soillvl<=SOIL_CRIT)
		{
			Lcd4_Clear();
			Lcd4_Set_Cursor(0,0);
			Lcd4_Write_String("SOIL CRITICAL");
			_delay_ms(2000);
			while(soillvl < SOIL_LOW)
			{
				turnOnPump();
			}
			turnOffPump();
			Lcd4_Clear();
		}
		else if(soillvl>=SOIL_MAX)
		{
			Lcd4_Clear();
			Lcd4_Set_Cursor(0,0);
			Lcd4_Write_String("Soil Good");
			_delay_ms(2000);
			Lcd4_Clear();
			turnOffPump();
		}
		//	PRINTING to LCD
		Lcd4_Clear();
		Lcd4_Set_Cursor(0,0);
		Lcd4_Write_String("T: %f, H: %f",temp,humidity);
		_delay_ms(2000);
		Lcd4_Clear();
		Lcd4_Set_Cursor(1,1);
		Lcd4_Write_String("soil-lvl: %d,water-lvl: %d",soillvl,waterlvl);
		_delay_ms(2000);
		Lcd4_Set_Cursor(4,2);
		Lcd4_Write_String("light status: %d",ADCSRA);
		_delay_ms(2000);


	}
	
}

