/*
 * relay.h
 *
 * Created: 11/28/2016 9:04:03 PM
 *  Author: dmaus
 */ 

#include <stdio.h>
#include <avr/io.h>

#ifndef RELAY_H_
#define RELAY_H_

#define relay_DDR DDRB
#define relay_PORT PORTB
#define relay_PIN PINB
#define relay_OUTPUTPIN PORTB0




#endif /* RELAY_H_ */