/*
 * SG90.c
 *
 * Created: 11/23/2016 11:16:27 AM
 *  Author: brent
 */ 


/*
SG90 Positions
0 (middle) = 1.5ms
90 (right) = 2ms
-90 (left) = 1ms
*/

#include "servo.h"
#include <util/delay.h>
#include <avr/io.h>


void WaitServo()
{
	uint16_t i;
	for(i=0;i<50;i++)
	{
		_delay_loop_2(0);
		_delay_loop_2(0);
		_delay_loop_2(0);
	}
}

//	turn servo to the middle
void turn_middle()
{
	OCR1A = 0.375;
	WaitServo();
}
void turn_right()
{
	OCR1A = 0.5;
	WaitServo();
}
void turn_left()
{
	OCR1A = 0.25; 
	WaitServo();
}

