/*
 * servo.h
 *
 * Created: 11/30/2016 9:33:45 AM
 *  Author: brent
 */ 


#define F_CPU 16000000
#ifndef SERVO_H_
#define SERVO_H_

#endif /* SERVO_H_ */

